// AI Justice Guardian Application
const app = {
  currentSection: 'home',
  currentStep: 1,
  uploadedFiles: [],
  reportData: {},
  
  // Sample data
  sampleCases: [
    { id: 'AJG-2025-1101-0001', type: 'Money Laundering', status: 'Under Investigation', amount: '$125,000', date: '2025-11-01', risk_score: 85, description: 'Structuring transactions through multiple accounts' },
    { id: 'AJG-2025-1103-0002', type: 'Cryptocurrency Fraud', status: 'Evidence Collection', amount: '$67,500', date: '2025-11-03', risk_score: 72, description: 'Fake ICO investment scheme' },
    { id: 'AJG-2025-1105-0003', type: 'Wire Fraud', status: 'Resolved - Recovered', amount: '$45,000', date: '2025-11-05', risk_score: 68, description: 'Business email compromise' },
    { id: 'AJG-2025-1107-0004', type: 'Identity Theft', status: 'Cross-Agency Collaboration', amount: '$23,400', date: '2025-11-07', risk_score: 55, description: 'Synthetic identity fraud' }
  ],
  
  sampleTransactions: [
    { tx_id: 'TX-2025110145891', from: 'Account ****3421', to: 'Account ****7829', amount: '$9,500', date: '2025-11-01 14:23:15', risk_level: 'Medium' },
    { tx_id: 'TX-2025110267234', from: 'Wallet 1A1zP1...kHS', to: 'Wallet 3J98t1...NqZ', amount: '2.5 BTC', date: '2025-11-02 09:15:42', risk_level: 'High' },
    { tx_id: 'TX-2025110398712', from: 'Account ****5643', to: 'Offshore Shell Corp', amount: '$50,000', date: '2025-11-03 16:45:23', risk_level: 'Critical' }
  ],
  
  evidenceItems: [
    { id: 'EV-2025-0001', type: 'Bank Statement', case_id: 'AJG-2025-1101-0001', upload_date: '2025-11-01', hash: 'a7f3c2d1e9b8f4a2c5d8e3f1a9b7c4d2', status: 'Verified', blockchain_ref: 'Block #145892' },
    { id: 'EV-2025-0002', type: 'Email Screenshot', case_id: 'AJG-2025-1103-0002', upload_date: '2025-11-03', hash: 'b2c8d4e1f7a3c9d5e2f8a4b7c3d9e1f6', status: 'Verified', blockchain_ref: 'Block #145967' }
  ],
  
  cryptoAddresses: [
    { address: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa', type: 'Bitcoin', balance: '0.34 BTC', transactions: 47, risk_level: 'Low', exchanges: ['Coinbase', 'Binance'] },
    { address: '3J98t1WpEZ73CNmYviecrnyiWrnqRhWNLy', type: 'Bitcoin', balance: '15.7 BTC', transactions: 234, risk_level: 'High', exchanges: ['Unknown Exchange', 'Mixer Detected'] }
  ],
  
  victimResources: [
    { title: '法律援助 / Legal Aid', description: 'Free legal consultation for crime victims', contact: '1-800-JUSTICE' },
    { title: '心理支持 / Psychological Support', description: 'Trauma counseling and mental health services', contact: '1-800-HELP-NOW' },
    { title: '金融恢复 / Financial Recovery', description: 'Asset recovery and victim compensation programs', contact: 'recovery@justice.gov' }
  ],
  
  // Initialize app
  init() {
    this.setupEventListeners();
    this.loadAlerts();
    this.loadEvidenceVault();
    this.loadResources();
    this.startStatisticsAnimation();
    this.updatePreview();
  },
  
  // Setup event listeners
  setupEventListeners() {
    // Description character count
    const descInput = document.getElementById('description');
    if (descInput) {
      descInput.addEventListener('input', (e) => {
        document.getElementById('char-count').textContent = e.target.value.length;
      });
    }
    
    // File upload
    const uploadZone = document.getElementById('upload-zone');
    const fileInput = document.getElementById('file-input');
    
    if (uploadZone && fileInput) {
      uploadZone.addEventListener('click', () => fileInput.click());
      
      uploadZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadZone.style.borderColor = 'var(--color-primary)';
      });
      
      uploadZone.addEventListener('dragleave', () => {
        uploadZone.style.borderColor = 'var(--color-border)';
      });
      
      uploadZone.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadZone.style.borderColor = 'var(--color-border)';
        this.handleFiles(e.dataTransfer.files);
      });
      
      fileInput.addEventListener('change', (e) => {
        this.handleFiles(e.target.files);
      });
    }
    
    // AI query enter key
    const aiQuery = document.getElementById('ai-query');
    if (aiQuery) {
      aiQuery.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
          this.sendAIQuery();
        }
      });
    }
  },
  
  // Navigation
  showSection(sectionId) {
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    document.getElementById(sectionId).classList.add('active');
    this.currentSection = sectionId;
    window.scrollTo(0, 0);
  },
  
  // Form navigation
  nextStep() {
    const currentStepEl = document.querySelector(`.form-step[data-step="${this.currentStep}"]`);
    const inputs = currentStepEl.querySelectorAll('input[required], select[required], textarea[required]');
    
    let valid = true;
    inputs.forEach(input => {
      if (!input.value && !document.getElementById('anonymous')?.checked) {
        valid = false;
        input.style.borderColor = 'var(--color-error)';
      } else {
        input.style.borderColor = 'var(--color-border)';
      }
    });
    
    if (!valid && this.currentStep === 1 && !document.getElementById('anonymous')?.checked) {
      this.showToast('请填写所有必填字段 / Please fill all required fields', 'error');
      return;
    }
    
    if (this.currentStep === 2) {
      const desc = document.getElementById('description').value;
      if (desc.length < 50) {
        this.showToast('描述至少需要50个字符 / Description needs at least 50 characters', 'error');
        return;
      }
    }
    
    document.querySelector(`.form-step[data-step="${this.currentStep}"]`).classList.remove('active');
    document.querySelector(`.progress-step[data-step="${this.currentStep}"]`).classList.add('completed');
    
    this.currentStep++;
    document.querySelector(`.form-step[data-step="${this.currentStep}"]`).classList.add('active');
    document.querySelector(`.progress-step[data-step="${this.currentStep}"]`).classList.add('active');
    
    if (this.currentStep === 5) {
      this.updateReviewSummary();
    }
    
    window.scrollTo(0, 0);
  },
  
  prevStep() {
    document.querySelector(`.form-step[data-step="${this.currentStep}"]`).classList.remove('active');
    document.querySelector(`.progress-step[data-step="${this.currentStep}"]`).classList.remove('active');
    
    this.currentStep--;
    document.querySelector(`.form-step[data-step="${this.currentStep}"]`).classList.add('active');
    document.querySelector(`.progress-step[data-step="${this.currentStep + 1}"]`).classList.remove('completed');
    
    window.scrollTo(0, 0);
  },
  
  toggleAnonymous() {
    const anonymous = document.getElementById('anonymous').checked;
    const personalFields = document.getElementById('personal-fields');
    
    if (anonymous) {
      personalFields.style.display = 'none';
      personalFields.querySelectorAll('input').forEach(input => input.required = false);
    } else {
      personalFields.style.display = 'block';
      personalFields.querySelectorAll('input').forEach(input => input.required = true);
    }
  },
  
  // File handling
  handleFiles(files) {
    Array.from(files).forEach(file => {
      const hash = this.generateHash(file.name);
      this.uploadedFiles.push({ name: file.name, hash, size: file.size });
    });
    
    this.updateFileList();
    this.showToast(`${files.length} 个文件已上传 / ${files.length} file(s) uploaded`, 'success');
  },
  
  updateFileList() {
    const fileList = document.getElementById('file-list');
    fileList.innerHTML = this.uploadedFiles.map(file => `
      <div class="file-item">
        <div>
          <div class="file-name">📎 ${file.name}</div>
          <div class="file-hash">Hash: ${file.hash}</div>
        </div>
        <button class="btn btn--secondary" style="padding: 4px 8px;" onclick="app.removeFile('${file.hash}')">删除 / Remove</button>
      </div>
    `).join('');
  },
  
  removeFile(hash) {
    this.uploadedFiles = this.uploadedFiles.filter(f => f.hash !== hash);
    this.updateFileList();
  },
  
  // Generate simple hash
  generateHash(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash).toString(16).padStart(32, '0');
  },
  
  // Update preview
  updatePreview() {
    const now = new Date();
    const caseId = `AJG-${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}-${String(Math.floor(Math.random() * 10000)).padStart(4, '0')}`;
    const hash = this.generateHash(caseId + now.toISOString());
    
    document.getElementById('preview-timestamp').textContent = now.toLocaleString('zh-CN');
    document.getElementById('preview-case-id').textContent = caseId;
    document.getElementById('preview-hash').textContent = hash;
  },
  
  // Update review summary
  updateReviewSummary() {
    const summary = document.getElementById('review-summary');
    const data = {
      '报告人 / Reporter': document.getElementById('anonymous')?.checked ? '匿名 / Anonymous' : document.getElementById('reporter-name')?.value,
      '日期 / Date': document.getElementById('incident-date')?.value,
      '犯罪类型 / Crime Type': document.getElementById('crime-type')?.value,
      '金额 / Amount': `${document.getElementById('currency')?.value} ${document.getElementById('amount')?.value}`,
      '描述 / Description': document.getElementById('description')?.value,
      '交易ID / Transaction IDs': document.getElementById('transaction-ids')?.value || 'N/A',
      '证据文件 / Evidence Files': `${this.uploadedFiles.length} 个文件 / ${this.uploadedFiles.length} file(s)`
    };
    
    summary.innerHTML = Object.entries(data).map(([key, value]) => `
      <div class="review-item">
        <div class="review-label">${key}:</div>
        <div>${value}</div>
      </div>
    `).join('');
    
    this.updatePreview();
  },
  
  // Submit report
  submitReport() {
    const caseId = document.getElementById('preview-case-id').textContent;
    
    const successMsg = `
      <p><strong>案件编号 / Case ID:</strong> ${caseId}</p>
      <p>您的报告已成功提交并记录在区块链上 / Your report has been successfully submitted and recorded on the blockchain</p>
      <p>您可以使用此案件ID追踪进度 / You can track progress using this Case ID</p>
      <div style="margin-top: 20px; padding: 16px; background: var(--color-bg-3); border-radius: 8px;">
        <strong>下一步 / Next Steps:</strong>
        <ul style="margin-top: 8px; padding-left: 20px;">
          <li>调查团队将在24小时内审核 / Investigation team will review within 24 hours</li>
          <li>您将收到案件确认邮件 / You will receive case confirmation email</li>
          <li>访问受害者支持中心获取帮助 / Visit Victim Support Center for assistance</li>
        </ul>
      </div>
    `;
    
    document.getElementById('success-message').innerHTML = successMsg;
    this.showModal('success-modal');
    
    // Reset form
    this.currentStep = 1;
    document.getElementById('report-form').reset();
    this.uploadedFiles = [];
    this.updateFileList();
    
    document.querySelectorAll('.form-step').forEach((step, index) => {
      step.classList.remove('active');
      if (index === 0) step.classList.add('active');
    });
    
    document.querySelectorAll('.progress-step').forEach((step, index) => {
      step.classList.remove('active', 'completed');
      if (index === 0) step.classList.add('active');
    });
  },
  
  // Search transaction
  searchTransaction() {
    const searchValue = document.getElementById('search-value').value;
    if (!searchValue) {
      this.showToast('请输入搜索值 / Please enter search value', 'error');
      return;
    }
    
    this.showToast('正在分析交易... / Analyzing transaction...', 'info');
    
    setTimeout(() => {
      const riskScore = this.calculateRiskScore(searchValue);
      this.displayAnalysisResults(riskScore, searchValue);
    }, 1500);
  },
  
  calculateRiskScore(searchValue) {
    let score = 30; // Base score
    
    if (searchValue.toLowerCase().includes('offshore')) score += 25;
    if (searchValue.toLowerCase().includes('shell')) score += 25;
    if (searchValue.toLowerCase().includes('crypto')) score += 10;
    if (searchValue.match(/\d{5,}/)) score += 15; // Large numbers
    if (Math.random() > 0.5) score += 10;
    
    return Math.min(score, 100);
  },
  
  displayAnalysisResults(riskScore, searchValue) {
    document.getElementById('analysis-results').style.display = 'block';
    
    // Risk score gauge
    this.drawRiskGauge(riskScore);
    
    // Risk level
    const riskLevel = document.getElementById('risk-level');
    if (riskScore < 30) {
      riskLevel.textContent = '低风险 / Low Risk';
      riskLevel.className = 'risk-level low';
    } else if (riskScore < 70) {
      riskLevel.textContent = '中等风险 / Medium Risk';
      riskLevel.className = 'risk-level medium';
    } else {
      riskLevel.textContent = '高风险 / High Risk';
      riskLevel.className = 'risk-level high';
    }
    
    // Draw flow chart
    this.drawFlowChart();
    
    // Display patterns
    this.displayPatterns(riskScore);
    
    // AI insights
    this.displayAIInsights(riskScore, searchValue);
    
    // Related cases
    this.displayRelatedCases();
    
    // Geo map
    this.displayGeoMap();
    
    document.querySelector('#analysis-results').scrollIntoView({ behavior: 'smooth' });
  },
  
  drawRiskGauge(score) {
    const canvas = document.getElementById('risk-gauge');
    const ctx = canvas.getContext('2d');
    const centerX = 150;
    const centerY = 150;
    const radius = 100;
    
    ctx.clearRect(0, 0, 300, 300);
    
    // Background arc
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0.75 * Math.PI, 0.25 * Math.PI);
    ctx.lineWidth = 20;
    ctx.strokeStyle = '#e0e0e0';
    ctx.stroke();
    
    // Score arc
    const endAngle = 0.75 * Math.PI + (score / 100) * 1.5 * Math.PI;
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0.75 * Math.PI, endAngle);
    ctx.lineWidth = 20;
    
    if (score < 30) ctx.strokeStyle = '#059669';
    else if (score < 70) ctx.strokeStyle = '#f59e0b';
    else ctx.strokeStyle = '#dc2626';
    
    ctx.stroke();
    
    document.getElementById('risk-score-display').textContent = score;
  },
  
  drawFlowChart() {
    const canvas = document.getElementById('flow-chart');
    const ctx = canvas.getContext('2d');
    canvas.width = canvas.offsetWidth;
    canvas.height = 400;
    
    const nodes = [
      { x: 100, y: 200, label: 'Source', color: '#1e3a8a' },
      { x: 300, y: 150, label: 'Account A', color: '#f59e0b' },
      { x: 300, y: 250, label: 'Account B', color: '#f59e0b' },
      { x: 500, y: 200, label: 'Shell Corp', color: '#dc2626' },
      { x: 700, y: 200, label: 'Destination', color: '#059669' }
    ];
    
    // Draw connections
    ctx.strokeStyle = '#999';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(nodes[0].x, nodes[0].y);
    ctx.lineTo(nodes[1].x, nodes[1].y);
    ctx.stroke();
    
    ctx.beginPath();
    ctx.moveTo(nodes[0].x, nodes[0].y);
    ctx.lineTo(nodes[2].x, nodes[2].y);
    ctx.stroke();
    
    ctx.beginPath();
    ctx.moveTo(nodes[1].x, nodes[1].y);
    ctx.lineTo(nodes[3].x, nodes[3].y);
    ctx.stroke();
    
    ctx.beginPath();
    ctx.moveTo(nodes[2].x, nodes[2].y);
    ctx.lineTo(nodes[3].x, nodes[3].y);
    ctx.stroke();
    
    ctx.beginPath();
    ctx.moveTo(nodes[3].x, nodes[3].y);
    ctx.lineTo(nodes[4].x, nodes[4].y);
    ctx.stroke();
    
    // Draw nodes
    nodes.forEach(node => {
      ctx.beginPath();
      ctx.arc(node.x, node.y, 30, 0, 2 * Math.PI);
      ctx.fillStyle = node.color;
      ctx.fill();
      ctx.strokeStyle = '#fff';
      ctx.lineWidth = 3;
      ctx.stroke();
      
      ctx.fillStyle = '#fff';
      ctx.font = '12px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(node.label, node.x, node.y + 50);
    });
  },
  
  displayPatterns(riskScore) {
    const patterns = [];
    
    if (riskScore > 70) {
      patterns.push({ name: '结构化交易检测 / Structuring Detected', confidence: 85 });
      patterns.push({ name: '跨境快速转移 / Rapid Cross-Border Movement', confidence: 78 });
    }
    if (riskScore > 50) {
      patterns.push({ name: '空壳公司指标 / Shell Company Indicators', confidence: 72 });
    }
    patterns.push({ name: '异常交易时间 / Unusual Transaction Timing', confidence: 65 });
    
    const html = patterns.map(p => `
      <div class="pattern-item">
        <div class="pattern-name">${p.name}</div>
        <div class="pattern-confidence">置信度 / Confidence: ${p.confidence}%</div>
      </div>
    `).join('');
    
    document.getElementById('patterns-list').innerHTML = html;
  },
  
  displayAIInsights(riskScore, searchValue) {
    const insights = `
      <h3>🤖 AI分析摘要 / AI Analysis Summary</h3>
      <p>基于${riskScore}的风险评分,此交易显示出${riskScore > 70 ? '高度' : riskScore > 50 ? '中等' : '较低'}可疑活动 / Based on the risk score of ${riskScore}, this transaction shows ${riskScore > 70 ? 'high' : riskScore > 50 ? 'moderate' : 'low'} suspicious activity.</p>
      <p><strong>建议行动 / Recommended Actions:</strong></p>
      <ul>
        <li>${riskScore > 70 ? '立即提交SAR报告 / File SAR immediately' : '继续监控 / Continue monitoring'}</li>
        <li>请求完整银行记录 / Request complete banking records</li>
        <li>交叉参考已知案例 / Cross-reference with known cases</li>
      </ul>
    `;
    
    document.getElementById('ai-insights').innerHTML = insights;
  },
  
  displayRelatedCases() {
    const cases = this.sampleCases.slice(0, 3);
    const html = cases.map(c => `
      <div class="related-case">
        <strong>${c.id}</strong> - ${c.type}<br>
        风险评分 / Risk Score: ${c.risk_score} | 状态 / Status: ${c.status}
      </div>
    `).join('');
    
    document.getElementById('related-cases-list').innerHTML = html;
  },
  
  displayGeoMap() {
    const mapDiv = document.getElementById('geo-map');
    mapDiv.innerHTML = `
      <div style="text-align: center; padding: 80px;">
        <h3>🌍 交易地理分布 / Transaction Geographic Distribution</h3>
        <p>检测到跨境交易: 美国 → 开曼群岛 → 瑞士 / Cross-border transactions detected: USA → Cayman Islands → Switzerland</p>
        <div style="margin-top: 20px; display: flex; justify-content: space-around;">
          <div>🇺🇸 United States</div>
          <div>→</div>
          <div>🏝️ Cayman Islands</div>
          <div>→</div>
          <div>🇨🇭 Switzerland</div>
        </div>
      </div>
    `;
  },
  
  // Evidence management
  loadEvidenceVault() {
    const vault = document.getElementById('evidence-vault');
    if (!vault) return;
    
    const html = this.evidenceItems.map(ev => `
      <div class="evidence-card" onclick="app.showEvidenceDetail('${ev.id}')">
        <div class="evidence-type">${ev.type}</div>
        <div class="evidence-id">${ev.id}</div>
        <div style="margin: 8px 0; font-size: 12px; color: var(--color-text-secondary);">
          案件 / Case: ${ev.case_id}<br>
          日期 / Date: ${ev.upload_date}
        </div>
        <div class="evidence-status ${ev.status}">${ev.status}</div>
      </div>
    `).join('');
    
    vault.innerHTML = html;
  },
  
  showEvidenceDetail(id) {
    const evidence = this.evidenceItems.find(e => e.id === id);
    if (!evidence) return;
    
    const detail = `
      <h3>${evidence.id}</h3>
      <div style="margin-top: 20px;">
        <p><strong>类型 / Type:</strong> ${evidence.type}</p>
        <p><strong>案件ID / Case ID:</strong> ${evidence.case_id}</p>
        <p><strong>上传日期 / Upload Date:</strong> ${evidence.upload_date}</p>
        <p><strong>哈希值 / Hash:</strong> <code>${evidence.hash}</code></p>
        <p><strong>区块链引用 / Blockchain Reference:</strong> ${evidence.blockchain_ref}</p>
        <p><strong>状态 / Status:</strong> <span class="evidence-status ${evidence.status}">${evidence.status}</span></p>
      </div>
      <div style="margin-top: 24px;">
        <h4>⛓️ 监管链 / Chain of Custody</h4>
        <div class="timeline-item completed">
          <strong>${evidence.upload_date} 09:23:15</strong><br>
          上传 / Uploaded by Investigation Team
        </div>
        <div class="timeline-item completed">
          <strong>${evidence.upload_date} 09:24:01</strong><br>
          PGP加密完成 / PGP Encryption Completed
        </div>
        <div class="timeline-item completed">
          <strong>${evidence.upload_date} 09:24:15</strong><br>
          区块链存储 / Stored on Blockchain: ${evidence.blockchain_ref}
        </div>
        <div class="timeline-item active">
          <strong>${evidence.upload_date} 10:15:32</strong><br>
          验证完成 / Verification Completed ✓
        </div>
      </div>
      <button class="btn btn--primary" style="margin-top: 20px;">📥 下载证据 / Download Evidence</button>
    `;
    
    document.getElementById('evidence-detail').innerHTML = detail;
    this.showModal('evidence-modal');
  },
  
  showUploadEvidence() {
    this.showToast('证据上传功能 / Evidence upload feature available', 'info');
  },
  
  // Victim support
  lookupCase() {
    const caseId = document.getElementById('case-lookup-id').value;
    if (!caseId) {
      this.showToast('请输入案件ID / Please enter Case ID', 'error');
      return;
    }
    
    const caseData = this.sampleCases.find(c => c.id === caseId);
    
    if (!caseData) {
      document.getElementById('case-status-result').innerHTML = `
        <div style="padding: 20px; background: var(--color-bg-4); border-radius: 8px;">
          <strong>未找到案件 / Case Not Found</strong><br>
          请检查案件ID是否正确 / Please check if the Case ID is correct
        </div>
      `;
      return;
    }
    
    const statusMap = {
      'Reported': { index: 0, text: '已报告 / Reported' },
      'Under Investigation': { index: 1, text: '调查中 / Under Investigation' },
      'Evidence Collection': { index: 2, text: '收集证据 / Evidence Collection' },
      'Cross-Agency Collaboration': { index: 3, text: '跨机构合作 / Cross-Agency Collaboration' },
      'Resolved - Recovered': { index: 4, text: '已解决-追回 / Resolved - Recovered' }
    };
    
    const currentStatus = statusMap[caseData.status] || statusMap['Reported'];
    
    const html = `
      <div style="background: var(--color-surface); padding: 24px; border-radius: 12px; border: 1px solid var(--color-card-border);">
        <h3>案件详情 / Case Details</h3>
        <p><strong>案件ID / Case ID:</strong> ${caseData.id}</p>
        <p><strong>类型 / Type:</strong> ${caseData.type}</p>
        <p><strong>金额 / Amount:</strong> ${caseData.amount}</p>
        <p><strong>日期 / Date:</strong> ${caseData.date}</p>
        <p><strong>当前状态 / Current Status:</strong> ${caseData.status}</p>
        
        <h4 style="margin-top: 24px;">调查进度 / Investigation Progress</h4>
        <div class="status-timeline">
          <div class="timeline-item ${currentStatus.index >= 0 ? 'completed' : ''}">
            <strong>1. 已报告 / Reported</strong><br>
            案件已成功提交 / Case successfully submitted
          </div>
          <div class="timeline-item ${currentStatus.index >= 1 ? 'active' : ''}">
            <strong>2. 调查中 / Under Investigation</strong><br>
            调查团队正在分析 / Investigation team analyzing
          </div>
          <div class="timeline-item ${currentStatus.index >= 2 ? 'active' : ''}">
            <strong>3. 收集证据 / Evidence Collection</strong><br>
            收集和验证证据 / Collecting and verifying evidence
          </div>
          <div class="timeline-item ${currentStatus.index >= 3 ? 'active' : ''}">
            <strong>4. 跨机构合作 / Cross-Agency Collaboration</strong><br>
            与其他机构协调 / Coordinating with other agencies
          </div>
          <div class="timeline-item ${currentStatus.index >= 4 ? 'completed' : ''}">
            <strong>5. 已解决 / Resolved</strong><br>
            案件结案 / Case closed
          </div>
        </div>
        
        <div style="margin-top: 24px; padding: 16px; background: var(--color-bg-3); border-radius: 8px;">
          <strong>下一步 / Next Steps:</strong><br>
          ${currentStatus.index < 4 ? '我们将在进展更新时通知您 / We will notify you of progress updates' : '感谢您的耐心等待 / Thank you for your patience'}
        </div>
      </div>
    `;
    
    document.getElementById('case-status-result').innerHTML = html;
  },
  
  loadResources() {
    const grid = document.getElementById('resources-grid');
    if (!grid) return;
    
    const html = this.victimResources.map(r => `
      <div class="resource-card">
        <div class="resource-title">${r.title}</div>
        <p>${r.description}</p>
        <div class="resource-contact">📞 ${r.contact}</div>
      </div>
    `).join('');
    
    grid.innerHTML = html;
  },
  
  // Cryptocurrency forensics
  analyzeCryptoAddress() {
    const address = document.getElementById('crypto-address').value;
    if (!address) {
      this.showToast('请输入加密货币地址 / Please enter crypto address', 'error');
      return;
    }
    
    const cryptoData = this.cryptoAddresses.find(c => c.address === address) || this.cryptoAddresses[0];
    
    document.getElementById('crypto-results').style.display = 'block';
    
    // Wallet overview
    const overview = `
      <div class="wallet-stat">
        <strong>类型 / Type</strong><br>
        ${cryptoData.type}
      </div>
      <div class="wallet-stat">
        <strong>余额 / Balance</strong><br>
        ${cryptoData.balance}
      </div>
      <div class="wallet-stat">
        <strong>交易数 / Transactions</strong><br>
        ${cryptoData.transactions}
      </div>
      <div class="wallet-stat">
        <strong>风险等级 / Risk Level</strong><br>
        <span style="color: ${cryptoData.risk_level === 'High' ? 'var(--danger-color)' : 'var(--success-color)'}">${cryptoData.risk_level}</span>
      </div>
    `;
    document.getElementById('wallet-overview').innerHTML = overview;
    
    // Transaction graph
    document.getElementById('transaction-graph').innerHTML = `
      <div style="text-align: center;">
        <h3>交易追踪图 / Transaction Tracing Graph</h3>
        <p>显示最多10跳的交易流向 / Showing transaction flow up to 10 hops</p>
        <div style="margin-top: 20px;">
          <span style="display: inline-block; padding: 12px 20px; background: #1e3a8a; color: white; border-radius: 20px; margin: 8px;">Input Address</span>
          <span>→</span>
          <span style="display: inline-block; padding: 12px 20px; background: #059669; color: white; border-radius: 20px; margin: 8px;">Exchange A</span>
          <span>→</span>
          <span style="display: inline-block; padding: 12px 20px; background: #f59e0b; color: white; border-radius: 20px; margin: 8px;">Mixer</span>
          <span>→</span>
          <span style="display: inline-block; padding: 12px 20px; background: #dc2626; color: white; border-radius: 20px; margin: 8px;">Unknown</span>
        </div>
      </div>
    `;
    
    // Exchange info
    const exchangeHtml = cryptoData.exchanges.map(ex => `
      <div class="exchange-item">
        <div>
          <strong>${ex}</strong><br>
          <span style="font-size: 12px; color: var(--color-text-secondary);">KYC: ${ex.includes('Unknown') ? '❌ Not Available' : '✅ Available'}</span>
        </div>
        <div style="font-size: 12px;">
          ${ex.includes('Unknown') ? '传票未就绪 / Subpoena Not Ready' : '传票就绪 / Subpoena Ready'}
        </div>
      </div>
    `).join('');
    document.getElementById('exchange-info').innerHTML = exchangeHtml;
    
    // Mixing detection
    const mixingHtml = `
      <div style="padding: 16px; background: ${cryptoData.risk_level === 'High' ? 'var(--color-bg-4)' : 'var(--color-bg-3)'}; border-radius: 8px;">
        <strong>混币服务检测 / Mixing Service Detection</strong><br>
        ${cryptoData.risk_level === 'High' ? '⚠️ 检测到混币活动 / Mixing activity detected' : '✅ 未检测到混币 / No mixing detected'}<br>
        <span style="font-size: 12px; margin-top: 8px; display: block;">混淆级别 / Obfuscation Level: ${cryptoData.risk_level === 'High' ? 'High (85%)' : 'Low (15%)'}</span>
      </div>
    `;
    document.getElementById('mixing-detection').innerHTML = mixingHtml;
    
    document.querySelector('#crypto-results').scrollIntoView({ behavior: 'smooth' });
  },
  
  // AI Assistant
  sendAIQuery() {
    const query = document.getElementById('ai-query').value;
    if (!query) return;
    
    this.askAI(query);
    document.getElementById('ai-query').value = '';
  },
  
  askAI(query) {
    const messagesDiv = document.getElementById('ai-messages');
    
    // User message
    messagesDiv.innerHTML += `<div class="ai-message user">${query}</div>`;
    
    // AI response
    setTimeout(() => {
      let response = '';
      
      if (query.toLowerCase().includes('10,000') || query.toLowerCase().includes('10000')) {
        response = `找到 3 个超过 $10,000 的交易:<br><br>
          1. TX-2025110398712: $50,000 (高风险 / High Risk)<br>
          2. TX-2025110145891: $9,500 (接近阈值 / Near Threshold)<br>
          3. AJG-2025-1101-0001: $125,000 (正在调查 / Under Investigation)<br><br>
          建议: 这些交易显示结构化模式,建议进一步调查 / Recommendation: These transactions show structuring patterns, further investigation recommended.`;
      } else if (query.toLowerCase().includes('suspect')) {
        response = `基于交易网络分析,发现以下关联 / Based on transaction network analysis, found the following connections:<br><br>
          • 空壳公司"Offshore Shell Corp"与3个已知嫌疑人账户有关联 / Shell company "Offshore Shell Corp" linked to 3 known suspect accounts<br>
          • 检测到与案件AJG-2025-1101-0001的共同交易模式 / Common transaction patterns detected with case AJG-2025-1101-0001<br>
          • 置信度: 78% / Confidence: 78%`;
      } else if (query.toLowerCase().includes('shell')) {
        response = `识别出 2 个空壳公司 / Identified 2 shell companies:<br><br>
          1. Offshore Shell Corp (开曼群岛 / Cayman Islands) - 风险评分 / Risk Score: 92<br>
          2. Global Trade Solutions Ltd (英属维尔京群岛 / BVI) - 风险评分 / Risk Score: 85<br><br>
          特征 / Characteristics: 快速资金流动,无实体业务 / Rapid fund movement, no physical business presence`;
      } else if (query.toLowerCase().includes('cross-border') || query.toLowerCase().includes('跨境')) {
        response = `跨境交易分析 / Cross-border Transaction Analysis:<br><br>
          • 检测到 15 个跨境交易 / 15 cross-border transactions detected<br>
          • 主要路径 / Primary routes: 美国 → 开曼群岛 → 瑞士 / USA → Cayman Islands → Switzerland<br>
          • 平均金额 / Average amount: $45,670<br>
          • 异常模式 / Anomaly: 72%的交易发生在非工作时间 / 72% of transactions occur during non-business hours<br>
          • GDPR合规状态 / GDPR Compliance: ✅ 已验证 / Verified`;
      } else {
        response = `我已分析您的查询 / I have analyzed your query. 基于当前数据,建议: / Based on current data, recommendations:<br><br>
          • 审查相关交易记录 / Review related transaction records<br>
          • 交叉参考已知案例数据库 / Cross-reference with known case database<br>
          • 考虑申请额外信息披露 / Consider requesting additional information disclosure<br><br>
          需要更具体的信息吗? / Need more specific information?`;
      }
      
      messagesDiv.innerHTML += `<div class="ai-message assistant">${response}</div>`;
      messagesDiv.scrollTop = messagesDiv.scrollHeight;
    }, 800);
    
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
  },
  
  // Alerts
  loadAlerts() {
    const alerts = [
      { time: '2分钟前 / 2 min ago', text: '检测到可疑的结构化交易 $9,800 / Suspicious structuring detected $9,800', level: 'high' },
      { time: '15分钟前 / 15 min ago', text: '加密货币混币服务活动 / Cryptocurrency mixing service activity', level: 'high' },
      { time: '1小时前 / 1 hour ago', text: '异常跨境转账至高风险地区 / Unusual cross-border transfer to high-risk region', level: 'medium' },
      { time: '3小时前 / 3 hours ago', text: '新案件提交: AJG-2025-1110-0015 / New case submitted: AJG-2025-1110-0015', level: 'low' }
    ];
    
    const html = alerts.map(a => `
      <div class="alert-item ${a.level}">
        <div class="alert-time">${a.time}</div>
        <div class="alert-text">${a.text}</div>
      </div>
    `).join('');
    
    document.getElementById('alert-list').innerHTML = html;
  },
  
  // Statistics animation
  startStatisticsAnimation() {
    setInterval(() => {
      const investigations = document.getElementById('stat-investigations');
      const resolved = document.getElementById('stat-resolved');
      const recovered = document.getElementById('stat-recovered');
      const victims = document.getElementById('stat-victims');
      
      if (Math.random() > 0.7) {
        const currentInv = parseInt(investigations.textContent);
        investigations.textContent = currentInv + (Math.random() > 0.5 ? 1 : -1);
      }
      
      if (Math.random() > 0.9) {
        const currentRes = parseInt(resolved.textContent);
        resolved.textContent = currentRes + 1;
      }
    }, 10000);
  },
  
  // Modal
  showModal(id) {
    document.getElementById(id).classList.add('active');
  },
  
  closeModal(id) {
    document.getElementById(id).classList.remove('active');
  },
  
  // Toast notifications
  showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    
    container.appendChild(toast);
    
    setTimeout(() => {
      toast.remove();
    }, 3000);
  }
};

// Initialize app when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => app.init());
} else {
  app.init();
}